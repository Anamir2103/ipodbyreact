//! andle menuButton to go back to previous menu(musicMenu/gameMenu/settingMenu)
import song1 from "../Audio/BangBang.mp3"
import song2 from "../Audio/JaiGanesh.mp3"
import song3 from "../Audio/Faded1.mp3"
import song4 from "../Audio/Faded2.mp3"

export const ArrayList = {
    Menu: [
        {
            parentIndex: 0,
            name: "Cover Flow",
            icon: "https://cdn-icons-png.flaticon.com/512/1544/1544767.png"
        },
        {
            parentIndex: 1,
            name: "Music",
            icon: "https://cdn-icons-png.flaticon.com/512/5907/5907562.png"
        },
        {
            parentIndex: 2,
            name: "Games",
            icon: "https://cdn-icons-png.flaticon.com/512/1068/1068778.png"
        },
        {
            parentIndex: 3,
            name: "Setting",
            icon: "https://cdn-icons-png.flaticon.com/512/747/747914.png"
        },
    ],
    Music: [
        {
            parentIndex: 4,
            name: "Songs",
            icon: "https://cdn-icons-png.flaticon.com/512/5907/5907562.png"
        },
        {
            parentIndex: 5,
            name: "Albums",
            icon: "https://cdn-icons-png.flaticon.com/512/2284/2284824.png"
        },
        {
            parentIndex: 6,
            name: "Artists",
            icon: "https://cdn-icons-png.flaticon.com/512/3604/3604722.png"
        },
        {
            parentIndex: 7,
            name: "Playlists",
            icon: "https://cdn-icons-png.flaticon.com/512/2284/2284784.png "
        }
    ],
    Games: [
        {
            parentIndex: 2,
            name: "SnakeGame",
            icon: "https://cdn-icons-png.flaticon.com/512/7863/7863115.png",
        },
        {
            parentIndex: 2,
            name: "Ping Pong",
            icon: "https://cdn-icons-png.flaticon.com/512/1545/1545719.png"
        },
        {
            parentIndex: 2,
            name: "Car Racing",
            icon: " https://cdn-icons-png.flaticon.com/512/9045/9045643.png"
        },
        {
            parentIndex: 2,
            name: "SkyCombat",
            icon: "https://cdn-icons-png.flaticon.com/512/6728/6728652.png"
        }
    ],
    Setting: [
        {
            parentIndex: 3,
            name: "Wallpaper",
            icon: "https://cdn-icons-png.flaticon.com/512/8979/8979955.png"
        },
        {
            parentIndex: 3,
            name: "Theme",
            icon: "https://cdn-icons-png.flaticon.com/512/3876/3876200.png"
        },
        {
            parentIndex: 3,
            name: "Date Time",
            icon: "https://cdn-icons-png.flaticon.com/512/1388/1388629.png"
        },
        {
            parentIndex: 3,
            name: "Language",
            icon: "https://cdn-icons-png.flaticon.com/512/5739/5739233.png"
        }
    ],
    Songs: [
        {
            parentIndex: 4,
            name: "Bang Bang",
            source: song1,
            duration: 135,
            icon: "https://static-koimoi.akamaized.net/wp-content/new-galleries/2014/09/bang-bang-music-review-news.jpg",
        },
        {
            parentIndex: 4,
            name: "Jai Ganesh",
            source: song2,
            duration: 329,
            icon: "https://i.pinimg.com/736x/d4/47/21/d44721cf40006845935a9505ecf69382.jpg",
        },
        {
            parentIndex: 4,
            name: "Faded1",
            source: song3,
            duration: 260,
            icon: "https://upload.wikimedia.org/wikipedia/en/d/da/Alan_Walker_-_Faded.png"
        },
        {
            parentIndex: 4,
            name: "Faded2",
            source: song4,
            duration: 181,
            icon: "https://i1.sndcdn.com/artworks-000169103463-rjkta2-t500x500.jpg"
        }        
    ],

    Album: [
        {
            parentIndex: 5,
            name: "Bhakti-Bhav",
            icon: "https://www.ratikantasingh.com/wp-content/uploads/2021/09/ganesh.jpg"
        },
        {
            parentIndex: 5,
            name: "Indian",
            icon: "https://peachmode.com/cdn/shop/articles/elements-of-indian-music-peachmode.jpg?v=1668998980"
        },
        {
            parentIndex: 5,
            name: "Hollywood",
            icon: "https://i.ytimg.com/vi/kFtXxmhoADg/maxresdefault.jpg"
        },
        {
            parentIndex: 5,
            name: "Marathi",
            icon: "https://qph.cf2.quoracdn.net/main-qimg-f095e8acb5735e5848f295eda90b700f-lq"
        }
    ],
    Artists: [
        {
            parentIndex: 6,
            name: "Arijit Singh",
            icon: "https://static.toiimg.com/thumb/msid-95487792,width-1280,resizemode-4/95487792.jpg"
        },
        {
            parentIndex: 6,
            name: "Sonu Nigam",
            icon: "https://dailymusicroll.s3.us-west-2.amazonaws.com/wp-content/uploads/2022/03/23151642/e4609000-7071-11ec-afdc-402d14cff529_1641641153526.jpg"
        },
        {
            parentIndex: 6,
            name: "Alka Yagnik",
            icon: "https://www.hindustantimes.com/ht-img/img/2023/04/05/1600x900/Alka-Yagnik-_1680670646394_1680670646715_1680670646715.jpg"
        },
        {
            parentIndex: 6,
            name: "Udit Narayan",
            icon: "https://images.hindustantimes.com/img/2021/05/25/1600x900/Screenshot_2021-04-24_at_11.21.31_AM_1619244068284_1621908269250.png"
        }
    ],
    Playlists: [
        {
            parentIndex: 7,
            name: "Favourite",
            icon: "https://cdn3.iconfinder.com/data/icons/love-and-valentine-3-1/136/152-512.png"
        },
        {
            parentIndex: 7,
            name: "Hindi",
            icon: "https://media.timeout.com/images/102136087/image.jpg"
        },
        {
            parentIndex: 7,
            name: "Marathi",
            icon: "https://i.ytimg.com/vi/xUSTF4Gyj8M/hqdefault.jpg"
        },
        {
            parentIndex: 7,
            name: "Malyalam",
            icon: "https://i.ytimg.com/vi/-DKK_76Lx98/maxresdefault.jpg"
        }
    ],
}
