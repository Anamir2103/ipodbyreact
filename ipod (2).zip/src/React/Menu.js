import React from "react";
import { ArrayList } from "./arrayList.js"
import CSS from "../CSS/Menu.module.css"
import { Component } from "react";

export default class Menu extends Component{


    // componentDidUpdate(){
    //     let option = document.getElementsByClassName("Menu_selectedOption__5btaS");
    //     option = option[0];
    //     let optionBoundry = option.getBoundingClientRect();
    //     let body = document.getElementsByClassName("Menu_options__NQ75L");
    //     body = body[0];
    //     let bodyBoundry = body.getBoundingClientRect();

    //     if(optionBoundry.bottom > bodyBoundry.bottom){
    //         body.scrollBy(0, 40);
    //     }
    //     if(optionBoundry.top < bodyBoundry.top){
    //         body.scrollBy(0, -40);
    //     }
    // }

    
    render(){
        const { selectedMenu, selectedOption } = this.props;
        const arrayMenu = Object.values(ArrayList)[selectedMenu];
        const menuName = Object.keys(ArrayList)[selectedMenu];
        return (<>
            <div className={CSS.body}>
                <div className={CSS.heading}>
                    <h1>{menuName}</h1>
                </div>
                <div className={CSS.options}>
                    {arrayMenu.map((option, index) => (
                        <div key={index}
                            className={`${CSS.item} ${index === selectedOption ? CSS.selectedOption : ''}`}>
                            <div className={CSS.optionName}>
                                 <h3>{option.name}</h3>
                            </div>
                            <div className={CSS.optionIcon}>
                                <img src={option.icon} alt="icon" />
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </>)
    }
}
